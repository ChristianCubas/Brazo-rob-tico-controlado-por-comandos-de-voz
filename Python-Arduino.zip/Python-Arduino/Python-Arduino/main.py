# Importando librerías a usar
import serial
import pyttsx3
import time
import speech_recognition as sr
import webbrowser as wb
import tkinter as tk
from tkinter import ttk,messagebox
from pdb import set_trace as breakpoint

#Nombre de la persona
dueño = "Christian"

# Solicitando hora mediante python
hora = time.strftime("%H")
hora = int(hora)

#Llamamos a Arduino
arduino = serial.Serial('COM3',9600)    

# Condicional para determinar si es día,tarde o noche
if hora <= 12:
    hour = "buenos días"
elif hora > 12 and hora <= 19:
    hour = "buenas tardes"
elif hora > 19:
    hour = "buenas noches"

# Saludo de bienvenida
engine = pyttsx3.init()
engine.say("Hola"+str(dueño)+", muy "+ hour)
engine.say("Preparado y listo para recibir instrucciones señor")
x = engine.runAndWait()
print(x)
# Ejecucion y proceso de los comandos de voz realizados
r = sr.Recognizer()

i = 1

while i>=1:
    with sr.Microphone() as source:
        audio = r.listen(source)
        try:
            text = r.recognize_google(audio, language="es")
            print(text)
            #Ejecuta la instruccion dad mediante voz
            if text=="dedo 1" or text== "D1" or text=="d1" or text=="uno" or text=="1":
                pyttsx3.speak("Moviendo dedo uno")
                arduino.write(b"dedo 1")
            elif text=="dedo 2"or text == "D2" or text=="d2" or text=="dos" or text=="2"  or text=="no" or text=="d23" or text=="22" or text=="222":
                pyttsx3.speak("Moviendo dedo dos")
                arduino.write(b"dedo 2")
            elif text=="dedo 3" or text == "D3" or text=="d3" or text=="tres" or text=="3" or text=="malcriado" or text=="33":
                pyttsx3.speak("Moviendo dedo tres")
                arduino.write(b"dedo 3")
            elif text=="dedo 4" or text == "D4" or text=="d4" or text=="cuatro" or text=="4":
                pyttsx3.speak("Moviendo dedo cuatro")
                arduino.write(b"dedo 4")
            elif text=="dedo 5" or text == "D5" or text=="d5" or text=="cinco" or text=="5":
                pyttsx3.speak("Moviendo dedo cinco")
                arduino.write(b"dedo 5")
            elif text == "puño" or text=="puño puño":
                pyttsx3.speak("Generando puño")
                arduino.write("contraer-puño".encode())
            elif text == "detener programa":
                pyttsx3.speak("Deteniendo el programa")
                i-=1
                break
            elif text=="agradece":
                pyttsx3.speak("Muchas gracias por todo, espero nos reencontremos en otra oportunidad. Muchas gracias salon por su atención 20 para el registro")
                wb.open("https://youtu.be/3GwjfUFyY6M?si=jFDxj7ItVoPWc1Ci")
                break
            else:
                pyttsx3.speak("Lo siento puedes volver a repetirlo por favor")
        except:
            pyttsx3.speak("No te puede entender")

arduino.close()